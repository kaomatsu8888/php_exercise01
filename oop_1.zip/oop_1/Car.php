<?php
class Car
{
    public $name;   // 車名(車種)
    public $number; // 車体番号
    public $color;  // カラー

    public function __construct($name, $number, $color) //コンストラクタdayo
    {
        $this->name = $name;    //nameプロパティに引数の値を代入
        $this->number = $number;    //numberプロパティに引数の値を代入
        $this->color = $color;  //colorプロパティに引数の値を代入
    }
    
    public function getName()   
    {
        return $this->name;
    }

    public function getNumber()
    {
        return $this->number;
    }

    public function getColor()
    {
        return $this->color;
    }

    public function setName($name)
    {
        return $this->name = $name;
    }

    public function setNumber($number)
    {
        return $this->number = $number;
    }

    public function setColor($color)
    {
        return $this->color = $color;
    }

    public function information()   // 車の情報を表示するメソッド
    {
        return '車の車種:' . $this->name. PHP_EOL .
        '車体番号:' . $this->number. PHP_EOL .
        'カラー:' . $this->color. PHP_EOL;
    }





}
